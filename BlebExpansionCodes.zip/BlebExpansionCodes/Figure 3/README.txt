AAA	Ax2 with Low confinement
AAB	TalA with low confinement
AAC	Ax2 with high confiment
AAD	TalA with low confinement

Click Source in RStudio to run code. 
