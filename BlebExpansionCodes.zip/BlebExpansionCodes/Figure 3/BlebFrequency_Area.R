# Load required libraries


# Set seed for generating random numbers
set.seed(1410)

# Set working directory
this.dir <- dirname(parent.frame(2)$ofile)
setwd(this.dir)

# Load files
Data_BlebArea = read.csv("Data_BlebArea.csv",header=T,na.strings="#NULL!")
Data_CellArea = read.csv("Data_CellArea.csv",header=T,na.strings="#NULL!")
Data_frequency = read.csv("Data_frequency.csv",header=T,na.strings="#NULL!")


#attach(Data_frequency)
#attach(Data_BlebArea)
#attach(Data_CellArea)

#Data_BlebArea=Data_BlebArea_microns
#Data_CellArea=Data_CellArea_microns

# Convert column to factor variables
Data_frequency$Cell = as.factor(Data_frequency$Cell)
Data_BlebArea$Cell = as.factor(Data_BlebArea$Cell)
Data_CellArea$Cell = as.factor(Data_CellArea$Cell)


# Generate Box Plot for bleb frequency
boxplot(Value ~ Cell,
     data = Data_frequency, 
     xlab = "Cell Environment", 
     ylab = "Blebs per cell",
     cex.lab = 1.5,
     cex.axis = 1.5,
     names = c("Ax2Low","TalALow","Ax2High","TalAHigh"))

# Generate Box Plot for bleb area
plot(Value ~ Cell,
     data = Data_BlebArea, 
     xlab = "Cell Environment", 
     ylab = "Bleb Area",
     cex.lab = 1.5,
     cex.axis = 1.5,
     names = c("Ax2Low","TalALow","Ax2High","TalAHigh"))

# Generate Box Plot for cell area
plot(Value ~ Cell,
     data = Data_CellArea, 
     xlab = "Cell Environment", 
     ylab = "Cell Area",
     cex.lab = 1.5,
     cex.axis = 1.5,
     names = c("Ax2Low","TalALow","Ax2High","TalAHigh"))

# Perform statistical tests
pairwise.wilcox.test(Data_BlebArea$Value, Data_BlebArea$Cell,
                     p.adjust.method = "BH")
pairwise.wilcox.test(Data_BlebArea$Value, Data_BlebArea$Cell,
                     p.adjust.method = "none")
pairwise.wilcox.test(Data_CellArea$Value, Data_CellArea$Cell,
                     p.adjust.method = "none")

