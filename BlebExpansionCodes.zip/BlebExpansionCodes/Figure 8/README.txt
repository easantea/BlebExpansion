To generate Figure 8 run BlebExpansion2D_LinkerStrength_Fig8
