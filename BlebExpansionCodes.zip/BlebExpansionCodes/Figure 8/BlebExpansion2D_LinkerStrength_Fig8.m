% Program to generate blebs in 2D
% Analysis of the effect of linker protein strength
% Emmanuel Asante-Asamani and Dinuka Sewwandi
% 12/31/2024

%*****************************************************************
close all; 
clear; 
clc
%*****************************************************************

% final time
t_val =linspace(0,10,6);
len = length(t_val);
link_parm = [0.005,0.01,0.05,0.1,0.2];         % Strength of single linker protein nN/(um)
load linkerData
l_star = [strain_vec1;strain_vec2];
rho_star = [density_vec1;density_vec2];
load cell_data_nobleb
final_area_nobleb_hp = final_area_hp;
final_area_nobleb_lp = final_area_lp;
cell_boundary_bleb = cell(1,5);
cell_boundary_critical = cell(1,5);


%% Initialize membrane points (circle) 

numpts = 50;
rad = 3.2;%5;%1;                            
tparm =  linspace(0,2*pi,numpts);        % membrane parameter space
xdata_ini = rad*cos(tparm);
ydata_ini = rad*sin(tparm);
xdata_ini(end) = xdata_ini(1);           % repeats the first point at the last point
ydata_ini(end)= ydata_ini(1);

% Construct parametric cubic spline
cseval_ini = [xdata_ini; ydata_ini];

% Calculate curvature and unit normals for initial circle
[cspline_ini,Curvature_ini,UnitNormal_ini,UnitTangent_ini]= splinecurvature(cseval_ini);
breaks = cspline_ini.breaks;                % parametrization
breaks0= breaks;
ptnum = length(breaks)-1;                   % number of distinct points
cell_area = cal_areafun(cspline_ini,ptnum);

%% Initialize blebbing region and initial condition for ode solver
region = (6:14);% with blebbing
%region = 100; % no blebbing

% % calculate strain
% I110 = l_star*UnitNormal_ini(1,:);
% I210 = l_star*UnitNormal_ini(2,:);
% P0  = rho_star*ones(1,ptnum);
% 
% % positions of cell membrane with strain
% xdata = xdata_ini+I110;
% ydata = ydata_ini+I210;
% 
% % Construct parametric cubic spline
% cseval = [xdata; ydata];
% 
% % Calculate curvature and unit normals
% [cspline,Curvature,UnitNormal,Tangent]= splinecurvature(cseval);
% breaks1 = cspline.breaks;                % parametrization


% I10 = l_star*UnitNormal(1,1:ptnum);
% I20 = l_star*UnitNormal(2,1:ptnum);
% P0  = rho_star*ones(1,ptnum);
%P0(region) = zeros(length(region),1);

%% Solve ode system high pressure

bleb_area_hp = ones(1,5);
critical_area_hp = ones(1,5);
final_area_hp = ones(1,5);
max_displacement_hp = ones(1,5);


% figure(1)
% set(0,'defaultaxesfontsize',25);
% color_mat=[ 0 0 0; 0 0.4470 0.7410;0.8500 0.3250 0.0980;0.4940 0.1840 0.5560;0.6350 0.0780 0.1840];
% linestyles = {'-','--',':','-','-'};

for i = 1:5
% calculate strain
I110 = l_star(1,i)*UnitNormal_ini(1,:);
I210 = l_star(1,i)*UnitNormal_ini(2,:);
P0  = rho_star(1,i)*ones(1,ptnum);

% positions of cell membrane with strain
xdata = xdata_ini+I110;
ydata = ydata_ini+I210;

% Construct parametric cubic spline
cseval = [xdata; ydata];

cell_boundary_critical{i}= cseval;

% Calculate critical area
[cspline,Curvature,UnitNormal,Tangent]= splinecurvature(cseval);
critical_area_hp(i) = cal_areafun(cspline,ptnum);

% intialize solution vector
y0 = zeros(5*ptnum,1);
y0(1:5:end-4) = I110(1:ptnum) ;
y0(2:5:end-3) =  I210(1:ptnum);
y0(3:5:end-2) = P0(1:ptnum);
y0(4:5:end-1) = xdata(1:end-1);
y0(5:5:end) = ydata(1:end-1);

% Solve problem
[t,y] = ode113(@(t,y) sysL1(t,y,region,Tangent,critical_area_hp(i),link_parm(i)),t_val,y0);

% Calculate final area and maximum displacement
xdataN = zeros(1,ptnum+1);
ydataN = zeros(1,ptnum+1);

I1N = y(end,1:5:end-4);
I2N = y(end,2:5:end-3);
max_displacement_hp(i) = max(sqrt(I1N.^2 + I2N.^2));
xdataN(1:end-1) = y(end,4:5:end-1);
ydataN(1:end-1) = y(end,5:5:end);
xdataN(end) = xdataN(1);                  
ydataN(end)= ydataN(1);

% Plot cell boundary
% plot(xdataN,ydataN,linestyles{i},'LineWidth',2.5,'Color',color_mat(i,:))
% hold on
% Construct parametric cubic spline
csevalN = [xdataN; ydataN];

% store cell boundary data
cell_boundary_bleb{i}= csevalN;

% Calculate critical area
[csplineN,Curvature,UnitNormal,Tangent]= splinecurvature(csevalN);
final_area_hp(i) = cal_areafun(csplineN,ptnum);

bleb_area_hp(i) = final_area_hp(i)- final_area_nobleb_hp(i);

end

% axis square;
% legend('$k_a=0.005$','$k_a=0.01$','$k_a=0.05$','$k_a=0.1$','$k_a=0.2$','Interpreter','latex')
% %title(sprintf('t = %d s',t_val(j)));
% hold off

%% Solve ode system low pressure

bleb_area_lp = ones(1,5);
critical_area_lp = ones(1,5);
final_area_lp = ones(1,5);
max_displacement_lp = ones(1,5);

% figure(2)
% set(0,'defaultaxesfontsize',25);
% color_mat=[ 0 0 0; 0 0.4470 0.7410;0.8500 0.3250 0.0980;0.4940 0.1840 0.5560;0.6350 0.0780 0.1840];
% linestyles = {'-','--',':','-','-'};

for i = 1:5
% calculate strain
I110 = l_star(2,i)*UnitNormal_ini(1,:);
I210 = l_star(2,i)*UnitNormal_ini(2,:);
P0  = rho_star(2,i)*ones(1,ptnum);

% positions of cell membrane with strain
xdata = xdata_ini+I110;
ydata = ydata_ini+I210;

% Construct parametric cubic spline
cseval = [xdata; ydata];

% Calculate critical area
[cspline,Curvature,UnitNormal,Tangent]= splinecurvature(cseval);
critical_area_lp(i) = cal_areafun(cspline,ptnum);

% intialize solution vector
y0 = zeros(5*ptnum,1);
y0(1:5:end-4) = I110(1:ptnum) ;
y0(2:5:end-3) =  I210(1:ptnum);
y0(3:5:end-2) = P0(1:ptnum);
y0(4:5:end-1) = xdata(1:end-1);
y0(5:5:end) = ydata(1:end-1);

% Solve problem
[t,y] = ode113(@(t,y) sysL2(t,y,region,Tangent,critical_area_lp(i),link_parm(i)),t_val,y0);

% Calculate final area and maximum displacement
xdataN = zeros(1,ptnum+1);
ydataN = zeros(1,ptnum+1);

I1N = y(end,1:5:end-4);
I2N = y(end,2:5:end-3);
max_displacement_lp(i) = max(sqrt(I1N.^2 + I2N.^2));
xdataN(1:end-1) = y(end,4:5:end-1);
ydataN(1:end-1) = y(end,5:5:end);
xdataN(end) = xdataN(1,1);                  
ydataN(end)= ydataN(1,1);

% Plot cell boundary
% plot(xdataN,ydataN,linestyles{i},'LineWidth',2.5,'Color',color_mat(i,:))
% hold on
% Construct parametric cubic spline
csevalN = [xdataN; ydataN];

% Calculate critical area
[csplineN,Curvature,UnitNormal,Tangent]= splinecurvature(csevalN);
final_area_lp(i) = cal_areafun(csplineN,ptnum);

bleb_area_lp(i) = final_area_lp(i)-final_area_nobleb_lp(i);

end
% 
% axis square;
% legend('$k_a=0.005$','$k_a=0.01$','$k_a=0.05$','$k_a=0.1$','$k_a=0.2$','Interpreter','latex')
% %title(sprintf('t = %d s',t_val(j)));
% hold off

%save cell_data_nobleb final_area_hp final_area_lp cell_boundary_nobleb

%% Extract solution and generate plots

%Show bleb size

figure(1)
set(0,'defaultaxesfontsize',25);
color_mat=[ 0 0 0; 0 0.4470 0.7410;0.8500 0.3250 0.0980;0.4940 0.1840 0.5560;0.6350 0.0780 0.1840];
linestyles = {'-o','--s',':d','-x','-^'};
linestylesb = {'-','--',':','-','-'};

% Linker strengh and bleb area
semilogx(link_parm,bleb_area_hp,linestyles{1},'LineWidth',2.5,'Color',color_mat(1,:))
hold on 
semilogx(link_parm,bleb_area_lp,linestyles{2},'LineWidth',2.5,'Color',color_mat(2,:))
legend('High Pressure','Low pressure','Interpreter','latex')
ylabel('Bleb area (\mum^2)')
xlabel('Linker Stiffness (nN/\mum)')
hold off

% figure(4)
% % Linker strengh and cell area
% 
% set(0,'defaultaxesfontsize',25); 
% semilogx(link_parm,bleb_area_hp./(final_area_hp-critical_area_hp),linestyles{1},'LineWidth',2.5,'Color',color_mat(1,:))
% hold on 
% semilogx(link_parm,bleb_area_lp./(final_area_lp-critical_area_lp),linestyles{2},'LineWidth',2.5,'Color',color_mat(2,:))
% legend('High Pressure','Low pressure','Interpreter','latex')
% ylabel(' Bleb Area Fraction (\mum^2)')
% xlabel('Linker Stiffness (nN/\mum)')
% hold off


figure(2)
set(0,'defaultaxesfontsize',25); 
for i=1:5
    subplot(2,3,i)
    data_critical = cell_boundary_critical{i};
    data_nobleb = cell_boundary_nobleb{i};
    data_bleb = cell_boundary_bleb{i};
    plot(data_critical(1,:),data_critical(2,:),linestylesb{1},'LineWidth',2.5,'Color',color_mat(1,:))
    hold on
    plot(data_nobleb(1,:),data_nobleb(2,:),linestylesb{2},'LineWidth',2.5,'Color',color_mat(2,:))
    plot(data_bleb(1,:),data_bleb(2,:),linestylesb{3},'LineWidth',2.5,'Color',color_mat(3,:))
    axis equal;
    title(sprintf('k_a = %.3f',link_parm(i)));
    legend('Critical','Nobleb','Bleb')
    hold off  
end

% %#################################################################################################
% % Show cell size
% figure(2)
% set(0,'defaultaxesfontsize',25);
% color_mat=[ 0 0 0; 0 0.4470 0.7410;0.8500 0.3250 0.0980;0.4940 0.1840 0.5560;0.6350 0.0780 0.1840];
% linestyles = {'-o','--s',':d','-x','-^'};
% 
% % Linker strength and area difference
% semilogx(link_parm,final_area_hp-critical_area_hp,linestyles{1},'LineWidth',2.5,'Color',color_mat(1,:))
% hold on 
% semilogx(link_parm,final_area_lp-critical_area_lp,linestyles{2},'LineWidth',2.5,'Color',color_mat(2,:))
% legend('High Pressure','Low pressure','Interpreter','latex')
% ylabel('Area Difference (\mum^2)')
% xlabel('Linker Stiffness (nN/\mum)')
% hold off
% 
% figure(3)
% set(0,'defaultaxesfontsize',25);
% color_mat=[ 0 0 0; 0 0.4470 0.7410;0.8500 0.3250 0.0980;0.4940 0.1840 0.5560;0.6350 0.0780 0.1840];
% % Linker strengh and critical area
% semilogx(link_parm,critical_area_hp,linestyles{1},'LineWidth',2.5,'Color',color_mat(1,:))
% hold on 
% semilogx(link_parm,critical_area_lp,linestyles{2},'LineWidth',2.5,'Color',color_mat(2,:))
% legend('High Pressure','Low pressure','Interpreter','latex')
% ylabel('Critical Area (\mum^2)')
% xlabel('Linker Stiffness (nN/\mum)')
% 
% hold off
% 
% figure(4)
% set(0,'defaultaxesfontsize',25);
% color_mat=[ 0 0 0; 0 0.4470 0.7410;0.8500 0.3250 0.0980;0.4940 0.1840 0.5560;0.6350 0.0780 0.1840];
% % Linker strengh and maximum displacement
% semilogx(link_parm,max_displacement_hp,linestyles{1},'LineWidth',2.5,'Color',color_mat(1,:))
% hold on 
% semilogx(link_parm,max_displacement_lp,linestyles{2},'LineWidth',2.5,'Color',color_mat(2,:))
% legend('High Pressure','Low pressure','Interpreter','latex')
% ylabel('Maximum Displacement (\mum)')
% xlabel('Linker Stiffness (nN/\mum)')
% 
% hold off
% 
