Guidelines to generate Figure 6 in manuscript.

Run BlebExpansion2D.m to generate Figure 6a
Run BlebExpansion2D_pressure.m to generate Figure 6b
Run BlebExpansion2D_MembraneStiffness.m to generate Figure 6c
Run BlebExpansion2D_CorticalStiffness.m to generate Figure 6d
Run BlebExpansion2D_CortexReformation.m to generate Figure 6e


