% calculate the are using cubic spline

function cal_areav = cal_areafun(csplinev,ptnumv)
% Inputs - csplinev: cubic splines
%          ptnumv : number of distinct points
% Output - cal_areav: Area of the cell



% coefficient matrix of cspline
coefMatrix = csplinev.coefs;

% breaks points in cspline
pbreak = csplinev.breaks;

ax = coefMatrix(1:2:end,4); % constant coeff. in x
bx = coefMatrix(1:2:end,3); % linear coeff. in x
cx = coefMatrix(1:2:end,2); % square coeff. in x
dx = coefMatrix(1:2:end,1); % cubic coeff. in x
%ay = coefMatrix(2:2:end,4); % constant coeff. in y
by = coefMatrix(2:2:end,3); % linear coeff. in y
cy = coefMatrix(2:2:end,2); % square coeff. in y
dy = coefMatrix(2:2:end,1); % cubic coeff. in y

% calculate resting area
area = zeros(ptnumv,1);
for i = 1: ptnumv
    area(i) = (ax(i)*by(i))*(pbreak(i+1)-pbreak(i))+(2*ax(i)*cy(i)+bx(i)*by(i))* ...
        ((pbreak(i+1)-pbreak(i))^2)/2 +(3*ax(i)*dy(i)+2*bx(i)*cy(i)+cx(i)*by(i))* ...
        ((pbreak(i+1)-pbreak(i))^3)/3 +(3*bx(i)*dy(i)+2*cx(i)*cy(i)+dx(i)*by(i))* ...
        ((pbreak(i+1)-pbreak(i))^4)/4 +(3*cx(i)*dy(i)+2*dx(i)*cy(i))*((pbreak(i+1)-pbreak(i))^5)/5 ...
        + (3*dx(i)*dy(i))*((pbreak(i+1)-pbreak(i))^6)/6;

end
cal_areav = sum(area);
end


