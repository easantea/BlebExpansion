function [csplinev, curvaturev,unitnorm,unittangent]= splinecurvature(pointsv)
% The function [csplinev, curvaturev,unitnorm] = splinecurvature(pointsv)
% calculates the curvature and unit normal vectors for an arbitrary closed
% curve defined by pointsv.
% INPUT: pointsv, 2 by M matrix where M is the number of points with the
%        last and first points repeated. 
% OUTPUT: curvaturev, the pointwise curvature at each point of the closed
%         curve
%          unitnorm, a 2 by M matrix containing the unit normal vectors at
%          each point of the closed curve.
%          unittangent, a 2 by M matrix containing the unit tangent vectors at
%          each point of the closed curve.
%          csplinev, a ppform for parametric cubic spline

% Compute spline
csplinev = cscvn(pointsv);

% Computing derivative of spline
csder = fnder(csplinev,1);

% Computing 2nd derivative of spline
cs2der = fnder(csplinev,2);

% Evaluate the derivative of spline function
sdevalv = fnval(csder,csder.breaks);

% Evaluate the 2nd derivative of spline function
sd2evalv = fnval(cs2der,cs2der.breaks);

%calculate curvature
XddYd = sd2evalv(1,:).* sdevalv(2,:);
XdYdd = sdevalv(1,:).* sd2evalv(2,:);
XdYd = sdevalv(1,:).^2 + sdevalv(2,:).^2;
curvaturev = abs(XddYd - XdYdd)./((XdYd).^(3/2));
unitnorm = [sdevalv(2,:)./XdYd.^(1/2);-sdevalv(1,:)./XdYd.^(1/2)];
% unittangent = [sdevalv(1,:)./XdYd.^(1/2);sdevalv(2,:)./XdYd.^(1/2)];
unittangent = [sdevalv(1,:);sdevalv(2,:)];

