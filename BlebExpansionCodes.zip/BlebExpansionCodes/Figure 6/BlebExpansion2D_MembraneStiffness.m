% Program to generate blebs in 2D
% Analysis of the effect of membrane stiffness
% Emmanuel Asante-Asamani and Dinuka Sewwandi
% 12/31/2024

%*****************************************************************
close all; 
clear; 
clc
%*****************************************************************

% final time
t_val =linspace(0,10,6);
len = length(t_val);
l_star =0.007928798437044;
rho_star = 99.878812019370443;

%% Initialize membrane points (circle) 

numpts = 50;
rad = 5;%5;%1;                            
tparm =  linspace(0,2*pi,numpts);        % membrane parameter space
xdata_ini = rad*cos(tparm);
ydata_ini = rad*sin(tparm);
xdata_ini(end) = xdata_ini(1);           % repeats the first point at the last point
ydata_ini(end)= ydata_ini(1);

% Construct parametric cubic spline
cseval_ini = [xdata_ini; ydata_ini];

% Calculate curvature and unit normals for initial circle
[cspline_ini,Curvature_ini,UnitNormal_ini,UnitTangent_ini]= splinecurvature(cseval_ini);
breaks = cspline_ini.breaks;                % parametrization
breaks0= breaks;
ptnum = length(breaks)-1;                   % number of distinct points
cell_area = cal_areafun(cspline_ini,ptnum);

%% Initialize blebbing region and initial condition for ode solver
region = (6:14);%[5:8 15:17 25:29];

% calculate strain
I110 = l_star*UnitNormal_ini(1,:);
I210 = l_star*UnitNormal_ini(2,:);

% positions of cell membrane with strain
xdata = xdata_ini+I110;
ydata = ydata_ini+I210;

% Construct parametric cubic spline
cseval = [xdata; ydata];

% Calculate curvature and unit normals
[cspline,Curvature,UnitNormal,Tangent]= splinecurvature(cseval);
breaks1 = cspline.breaks;                % parametrization


I10 = l_star*UnitNormal(1,1:ptnum);
I20 = l_star*UnitNormal(2,1:ptnum);
P0  = rho_star*ones(1,ptnum);
%P0(region) = zeros(length(region),1);

%% Solve ode system

y0 = zeros(5*ptnum,1);

y0(1:5:end-4) = I10;
y0(2:5:end-3) = I20;
y0(3:5:end-2) = P0;
y0(4:5:end-1) = xdata(1:end-1);
y0(5:5:end) = ydata(1:end-1);

[t1,y1] = ode113(@(t,y) sysM1(t,y,region,Tangent,cell_area),t_val,y0);
[t2,y2] = ode113(@(t,y) sysM2(t,y,region,Tangent,cell_area),t_val,y0);
[t3,y3] = ode113(@(t,y) sysM3(t,y,region,Tangent,cell_area),t_val,y0);
[t4,y4] = ode113(@(t,y) sysM4(t,y,region,Tangent,cell_area),t_val,y0);
[t5,y5] = ode113(@(t,y) sysM5(t,y,region,Tangent,cell_area),t_val,y0);

%% Extract solution and generate plots

xdataN = zeros(ptnum+1,5);
ydataN = zeros(ptnum+1,5);


% test data 1
xdataN(1:end-1,1) = y1(end,4:5:end-1);
ydataN(1:end-1,1) = y1(end,5:5:end);
xdataN(end,1) = xdataN(1,1);                  
ydataN(end,1)= ydataN(1,1);

% test data 2
xdataN(1:end-1,2) = y2(end,4:5:end-1);
ydataN(1:end-1,2) = y2(end,5:5:end);
xdataN(end,2) = xdataN(1,2);                  
ydataN(end,2)= ydataN(1,2);


% test data 3
xdataN(1:end-1,3) = y3(end,4:5:end-1);
ydataN(1:end-1,3) = y3(end,5:5:end);
xdataN(end,3) = xdataN(1,3);                  
ydataN(end,3)= ydataN(1,3);

% test data 4
xdataN(1:end-1,4) = y4(end,4:5:end-1);
ydataN(1:end-1,4) = y4(end,5:5:end);
xdataN(end,4) = xdataN(1,4);                  
ydataN(end,4)= ydataN(1,4);

% test data 5
xdataN(1:end-1,5) = y5(end,4:5:end-1);
ydataN(1:end-1,5) = y5(end,5:5:end);
xdataN(end,5) = xdataN(1,5);                  
ydataN(end,5)= ydataN(1,5);


figure(1)
set(0,'defaultaxesfontsize',25);
color_mat=[ 0 0 0; 0 0.4470 0.7410;0.8500 0.3250 0.0980;0.4940 0.1840 0.5560;0.6350 0.0780 0.1840];

for j=1:5
    plot(xdataN(:,j),ydataN(:,j),'LineWidth',2.5,'Color',color_mat(j,:))
    hold on 
end
axis square;
legend('$k_m=0.1\tilde{k}_m$', '$k_m=0.5\tilde{k}_m$','$k_m=\tilde{k}_m$','$k_m=5\tilde{k}_m$','$k_m=10\tilde{k}_m$','Interpreter','latex')
%title(sprintf('t = %d s',t_val(j)));
hold off


