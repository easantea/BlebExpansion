% Visualizing equilibrium strain and linker density
% Emmanuel Asante-Asamani
% 12/18/2024

% Model parameters
F0 = 0.08;                              % Resting hydrostatic pressure in nN/(um)^2
m = 0.1;                                % Rate at which driving pressure is relieved 1/(um)
km = 0.00392;                           % Membrane elastic stiffness nN/(um)^3
%ka = [0.005,0.01,0.05,0.1,0.2];         % Strength of single linker protein nN/(um)
%ka = [0.000625,0.00125,0.0025,0.005,0.01];
% ka = [0.0025,0.005,0.01,0.05,0.1]; 
ka = [0.005,0.01,0.05,0.1,0.2]; 

rho_0 = 100;                            % Total available density of linker proteins 1/(um)^2
k_on = 10000;                           % Binding rate of linker protein 1/s
k_off = 10;                             % Unbinding rate of linker protein 1/s
beta = 1.e6/4.1;                        % Inverse of thermal energy in nN/(um)
delta = 0.001;                          % Characteristic bond length in um

%% Define nonlinear function 
% High Pressure
strain_vec1 = zeros(1,5);
density_vec1 = zeros(1,5);

for i = 1:5
    klink = ka(i);
    myfun = @(x) [F0*exp(-m*x(1))-(km+klink*x(2))*x(1); k_on*(rho_0-x(2))- k_off*x(2)*exp(beta*klink*x(1)*delta)];
    % Solve nonlinear system
    x0 = [1.e-3;100-1.e-3];
    x = fsolve(myfun,x0);
    strain_vec1(i) = x(1);
    density_vec1(i) = x(2);
end

% Low Pressure
strain_vec2 = zeros(1,5);
density_vec2 = zeros(1,5);
F0=0.06;

for i = 1:5
    klink = ka(i);
    myfun = @(x) [F0*exp(-m*x(1))-(km+klink*x(2))*x(1); k_on*(rho_0-x(2))- k_off*x(2)*exp(beta*klink*x(1)*delta)];
    % Solve nonlinear system
    x0 = [1.e-3;100-1.e-3];
    x = fsolve(myfun,x0);
    strain_vec2(i) = x(1);
    density_vec2(i) = x(2);
end
save linkerData density_vec1 density_vec2 strain_vec1 strain_vec2

%% Effect of linker strength on critical strain
figure(1)
set(0,'defaultaxesfontsize',25);
linestyles = {'-o','--s',':d','-x','-^'};
color_mat=[ 0 0 0; 0 0.4470 0.7410;0.8500 0.3250 0.0980;0.4940 0.1840 0.5560;0.6350 0.0780 0.1840];
plot(ka,strain_vec1,linestyles{1},'LineWidth',3,'Color',color_mat(1,:),'MarkerSize',5)
hold on
plot(ka,strain_vec2,linestyles{2},'LineWidth',3,'Color',color_mat(2,:),'MarkerSize',5)
xlabel('Linker Stiffness, k_a (nN/\mu m)')
ylabel('Critical Strain (\mu m)')
legend('$F_0=0.08$','$F_0=0.06$','Interpreter','latex')
grid on
hold off