%*****************************************************************
close all; 
clear; 
clc
%*****************************************************************
% This code check the actin reformation

% final time
t_val =linspace(0,6,4);
len = length(t_val);


% l_dot=0 and rho_dot =0 k_a =0.1,F=0.08, a_rest =78.7865
l_star =0.007928798437044;
rho_star = 99.878812019370443;


% % l_dot=0 and rho_dot =0 k_a =0.2,F=0.08, a_rest = 78.6624
% l_star= 0.003984528350955;
% rho_star = 99.878693109793971 ;

% % l_dot=0 and rho_dot =0 k_a =0.3,F=0.08, a_rest = 78.6208
% l_star=  0.002660855716688;
% rho_star = 99.878653178296005 ;

% % l_dot=0 and rho_dot =0 k_a =0.002,F=0.08, a_rest = 87.0884
% l_star = 0.265170538477653;
% rho_star = 99.886320370431960;

% % l_dot=0 and rho_dot =0 k_a =0.004,F=0.08, a_rest = 83.6290
% l_star = 0.159536329735465;
% rho_star = 99.883295201556521;

% % l_dot=0 and rho_dot =0 k_a =0.006,F=0.08, a_rest = 82.1622
% l_star = 0.114088209042499;
% rho_star =99.881968972679473;

% % l_dot=0 and rho_dot =0 k_a =0.008,F=0.08, a_rest = 81.3514
% l_star = 0.088793209817920;
% rho_star =99.881224308774080 ;

% % l_dot=0 and rho_dot =0 k_a =0.01,F=0.08, a_rest = 80.8370
% l_star = 0.072679207011279;
% rho_star = 99.880747474508112;
    
%  % l_dot=0 and rho_dot =0 k_a =0.02,F=0.08, a_rest = 79.7388
% l_star = 0.038104049975646;
% rho_star = 99.879717871370772;

%  % l_dot=0 and rho_dot =0 k_a =0.03,F=0.08, a_rest = 79.3505
% l_star = 0.025820607149249;
% rho_star = 99.879349947299332;

%  % l_dot=0 and rho_dot =0 k_a =0.04,F=0.08, a_rest = 79.1518
% l_star = 0.019526070829559;
% rho_star = 99.879160971490720;

% % l_dot=0 and rho_dot =0 k_a =0.05,F=0.08, a_rest = 79.0312
% l_star = 0.015698980536809;
% rho_star = 99.879045928960934;
 
%  % l_dot=0 and rho_dot =0 k_a =0.07,F=0.08, a_rest = 78.8919
% l_star = 0.011278019689090;
% rho_star = 99.878912898112347;




% % l_dot=0 and rho_dot =0 k_a =0.002,F=0.06, a_rest = 84.9090
% l_star =  0.198873139715611;
% rho_star =99.889933997623118;

% % l_dot=0 and rho_dot =0 k_a =0.004,F=0.06, a_rest = 82.3409
% l_star = 0.119648000764061;
% rho_star = 99.887744585880000 ;

% % l_dot=0 and rho_dot =0 k_a =0.006,F=0.06, a_rest = 81.2482
% l_star = 0.085562627721785;
% rho_star = 99.886789259861942;

% % l_dot=0 and rho_dot =0 k_a =0.008,F=0.06, a_rest = 80.6431
% l_star = 0.066591933329080;
% rho_star = 99.886254037961763;

% % l_dot=0 and rho_dot =0 k_a =0.01,F=0.06, a_rest = 80.2589
% l_star = 0.054506847959476;
% rho_star = 99.885911760020136;

% % l_dot=0 and rho_dot =0 k_a =0.02,F=0.06, a_rest = 79.4375
% l_star = 0.028576552246846;
% rho_star = 99.885173868905440;

% % l_dot=0 and rho_dot =0 k_a =0.03,F=0.06, a_rest = 79.1467
% l_star = 0.019364412742789;
% rho_star = 99.884910572813510;

% % l_dot=0 and rho_dot =0 k_a =0.04,F=0.06, a_rest = 78.9979
% l_star = 0.014643750439422;
% rho_star = 99.884775415369802;

% % l_dot=0 and rho_dot =0 k_a =0.05,F=0.06, a_rest = 78.9075
% l_star = 0.011773583029851;
% rho_star = 99.884693161828295;

% % % l_dot=0 and rho_dot =0 k_a =0.07,F=0.06, a_rest = 78.8031
% l_star = 0.008458040246992;
% rho_star = 99.884598071485044;
 
% % l_dot=0 and rho_dot =0 k_a =0.1,F=0.06, a_rest = 78.7241
% l_star= 0.005946262084644;
% rho_star =  99.884525980978211; 

% % l_dot=0 and rho_dot =0 k_a =0.2,F=0.06, a_rest = 78.6311
% l_star= 0.002988225166935;
% rho_star =  99.884441024580340;

% % % l_dot=0 and rho_dot =0 k_a =0.3,F=0.06, a_rest = 78.5999
% l_star= 0.001995527109137;
% rho_star =  99.884412499738730;



%% Initialize membrane points (circle) 
numpts = 50;
rad = 5;%5;%1;                            
tparm =  linspace(0,2*pi,numpts);        % membrane parameter space
xdata_ini = rad*cos(tparm);
ydata_ini = rad*sin(tparm);
xdata_ini(end) = xdata_ini(1);           % repeats the first point at the last point
ydata_ini(end)= ydata_ini(1);

% Construct parametric cubic spline
cseval_ini = [xdata_ini; ydata_ini];

% Calculate curvature and unit normals for initial circle
[cspline_ini,Curvature_ini,UnitNormal_ini,UnitTangent_ini]= splinecurvature(cseval_ini);
breaks = cspline_ini.breaks;                % parametrization
breaks0= breaks;
ptnum = length(breaks)-1;                   % number of distinct points
%area = cal_areafun(cspline,ptnum);

%% Initialize blebbing region and initial condition for ode solver
region = (6:12);%[5:8 15:17 25:29];

% calculate strain
I110 = l_star*UnitNormal_ini(1,:);
I210 = l_star*UnitNormal_ini(2,:);

% positions of cell with strain
xdata = xdata_ini+I110;
ydata = ydata_ini+I210;

% Construct parametric cubic spline
cseval = [xdata; ydata];

% Calculate curvature and unit normals
[cspline,Curvature,UnitNormal,UnitTangent]= splinecurvature(cseval);
breaks1 = cspline.breaks;                % parametrization
area = cal_areafun(cspline,ptnum);


I10 = l_star*UnitNormal(1,1:ptnum);
I20 = l_star*UnitNormal(2,1:ptnum);
P0  = rho_star*ones(1,ptnum);
%P0(region) = zeros(length(region),1);

%% Solve ode system

y0 = zeros(5*ptnum,1);

y0(1:5:end-4) = I10;
y0(2:5:end-3) = I20;
y0(3:5:end-2) = P0;
y0(4:5:end-1) = xdata(1:end-1);
y0(5:5:end) = ydata(1:end-1);


[t,y] = ode113(@(t,y) sys(t,y,region,UnitTangent),t_val,y0);


I1N = zeros(ptnum,len);
I2N = zeros(ptnum,len);
PN = zeros(ptnum,len);
xdataN = zeros(ptnum+1,len);
ydataN = zeros(ptnum+1,len);

for i =1:len
    I1N(:,i) = y(i,1:5:end-4);
    I2N(:,i) = y(i,2:5:end-3);
    PN(:,i) = y(i,3:5:end-2);
    xdataN(1:end-1,i) = y(i,4:5:end-1);
    ydataN(1:end-1,i) = y(i,5:5:end);
    xdataN(end,i) = xdataN(1,i);                   % repeats the first point at the last point
    ydataN(end,i)= ydataN(1,i);
end



% Construct parametric cubic spline
csevalN = [xdataN(:,end)'; ydataN(:,end)'];

% Calculate curvature and unit normals
[csplineN1,CurvatureN1,UnitNormalN1,UnitTangentN1]= splinecurvature(csevalN);
breaksN1 = csplineN1.breaks;                % parametrization
areaN = cal_areafun(csplineN1,ptnum);



figure(1)
for j=1:len
    subplot(2, 2, j) ;
    set(0,'defaultaxesfontsize',25);
    plot(xdataN(:,1),ydataN(:,1),'LineWidth',2.5)
    hold on 
    plot(xdataN(:,j),ydataN(:,j),'r*-','LineWidth',2.5)
    axis equal;
    title(sprintf('t = %.2d s',t_val(j)));
    hold on
end

% set(0,'defaultaxesfontsize',45);
% %plot(xdataN(:,1),ydataN(:,1),'LineWidth',2.5)           % plot initial interface
% % hold on 
% plot(xdataN(:,len),ydataN(:,len),'r-','LineWidth',4.5) % plot last interface
% % plot unit normal vectors
% %quiver(csevalN(1,:),csevalN(2,:),UnitNormalN1(1,:),UnitNormalN1(2,:));
% axis equal;



% % figure(1)
% % for j=1:len
% %     subplot(3, 2, j) ;
% %     plot(xdataN(:,j),ydataN(:,j))
% %     axis equal;
% %     title(sprintf('Iteration:%d',j));
% %     hold on
% % end

% figure(1)
% %subplot(2,1,1)
% plot(xdataN(:,1),ydataN(:,1))
% hold on 
% plot(xdataN(:,len),ydataN(:,len),'r*-')
% %quiver(csevalN(1,:),csevalN(2,:),UnitNormalN1(1,:),UnitNormalN1(2,:));
% axis equal;
% title(sprintf('Iteration:%d',1));

% subplot(2,1,2)
% plot(xdataN(:,len),ydataN(:,len))
% hold on
% %quiver(csevalN(1,:),csevalN(2,:),UnitNormalN1(1,:),UnitNormalN1(2,:)); % plot normal vectors
% axis equal;
% title(sprintf('Iteration:%d',len));



%% function using to solve l and rho_a with ode45
function sol_sys = sys(t,y,region,UnitTangent)

P0_cell = 0.08;%0.06;%0.08;             % Cellular pressure nN/(um)^2
k_a = 0.1;%0.1;%10^(-1);%0.001;       % Strength of single adhesion protein  nN/(um)

k_on = 10^4;                % Binding rate of adhesion protein s^(-1)
k_0_off = 10;               % Detaching rate of adhesion protein S^(-1)
b = 10^(6)/4.1;
k =k_a;
%k = 10^(-1);                % Elastic constant of spring like linkers nN/(um)
delta = 10^(-3);            % characteristic bond length (um)
rho_0 = 10^2;               % Total available density of adhesion protein (um)^(-2)

k0_c = 0.098;               % Spring constant for the cortex nN/(um)^3
tau0_c = 0.064;              % Viscosity coefficient of the full cortex nNs/(um)^3
tau0_y =6.09;          % Viscosity coefficient of cytoplasm nNs/(um)^3

P_start =0.05;%0.04;%0.05;        % presure due to contraction nN/(um)^2 % 0.05 for P0=0.08 & 0.04 for P0=0.06
% P_e = 0.02;               % enviranment pressure nN/(um)^2
k_cell = 0.225;%225 ;%2250;                    % cell bulk modulus (nN/(um)^2)

% Actin concentration

k_a_on = 0.7602;                          % rate of assembly
k_a_off = 0.4344;                         % rate of disassembly
k_a_off_eq = 0.4344;
k_a_off_D =0.0160; %0.0120;                        % rate of disassembly of degradation
actin_rest = k_a_on/k_a_off;              % actin concentration in the expanding bleb
actin_0_rest = k_a_on/k_a_off_eq;         % Resting actin concentration in the expanding bleb

actin_con = actin_rest * (1-exp(-k_a_off*t)); % fraction of cortex actin

actin_frac = actin_con/actin_0_rest;

const_elast = 1/25;                              % potion of cotical elasticity
const_visco = 1/25;                              % potion of viscosity of cotex
k_m = const_elast*k0_c;                          % membrane elasticity

time_lap = 2;

gamma_mem = 0.032;%0.032;%0.024;%40;              % membrane tension (nN/um) % 0.032 for high P & 0.024 for low P
gamma_cor = 0.1;%250;                      % cortical tension (nN/um) %same for both low & high pressure


area_rest = 78.7865;          % constant value %78.7865 is the resting area for cell when P0 =0.08 & k_a =0.1

% separating I1,I2,P,xdata,ydata values from the y0
I1 = y(1:5:end-4);
I2 = y(2:5:end-3);
P = y(3:5:end-2);
P(region) = zeros(length(region),1);
xdata = y(4:5:end-1);
ydata = y(5:5:end);
xdata(end+1) = xdata(1);                   % repeats the first point at the last point
ydata(end+1)= ydata(1);


% Construct parametric cubic spline
csevalN = [xdata'; ydata'];

% Calculate curvature and unit normals
[csplineN,CurvatureN,UnitNormalN,UnitTangentN]= splinecurvature(csevalN);
breaks = csplineN.breaks;                % parametrization
%breaks0= breaks;
UnitTangent_ini = UnitTangent;
ptnum = length(breaks)-1;               % number of distinct points
P_bleb =  2*(gamma_mem+gamma_cor)*CurvatureN(1:ptnum);
area_new = cal_areafun(csplineN,ptnum);   % calculating new area


%P_total = P0_cell + P_start;
cha_bleb = zeros(1,ptnum);
P_total = zeros(1,ptnum);
dI1dt = zeros(1,ptnum);
dI2dt = zeros(1,ptnum);
dPdt  = zeros(1,ptnum);
dX1dt = zeros(1,ptnum);
dX2dt = zeros(1,ptnum);
norm_tan = zeros(1,ptnum);

sol_sys = zeros(5*ptnum,1);
% dot_tan_V = dot(UnitTangent(:,1:ptnum),v);


I = [I1';I2']; 
% A =UnitTangentN(:,1:ptnum);               % use new tangent
A =UnitTangent_ini(:,1:ptnum);              % use old tangent
dot_tan_I = dot(A,I,1);

% belb without cortex
if t < time_lap
    k_b = k_m+ k0_c;                           % elastisity of boundary for general cell area
    tau_c = const_visco*tau0_c;                % viscosity of blebbing area
    tau_y = const_visco*tau0_y;                % viscosity of blebbing area
    
    k_b_bleb = k_m;                            % elastisity of boundary for blebbing region (allowing cortex reformation)

    % for the 1st point
    % norm_tan(1) = norm(UnitTangentN(:,1));
    norm_tan(1) = norm(UnitTangent_ini(:,1));
    
    if 1 >= region(1)&& 1<= region(end)   
    % for blebbing region
        cha_bleb(1)=1;
    
        P_total(1) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(1)*cha_bleb(1);  % driving presure

    
        dI1dt(1) = (P_total(1)*UnitNormalN(1,1))/tau_c - (k_b_bleb + k_a*P(1))*I1(1)/tau_c + (dot_tan_I(1)*(k_b_bleb + k_a*P(1))*(I1(2)-I1(ptnum)))/...
        (((norm_tan(1))^2)*tau_c*(2*(breaks(2)-breaks(ptnum))));

        dI2dt(1) = (P_total(1)*UnitNormalN(2,1))/tau_c - (k_b_bleb + k_a*P(1))*I2(1)/tau_c + (dot_tan_I(1)*(k_b_bleb + k_a*P(1))*(I2(2)-I2(ptnum)))/...
        (((norm_tan(1))^2)*tau_c*(2*(breaks(2)-breaks(ptnum))));

        dPdt(1) = k_on*(rho_0-P(1)) - k_0_off*exp(b*k*delta*norm(I(:,1)))*P(1) + (dot_tan_I(1)*(k_b_bleb + k_a*P(1))*(P(2)-P(ptnum)))/...
        (((norm_tan(1))^2)*tau_c*(2*(breaks(2)-breaks(ptnum))));

        % sqrt(I1(1)^2+I2(1)^2);
        dX1dt(1) = (P_total(1)*UnitNormalN(1,1))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(1))*I1(1)/tau_c;

        dX2dt(1) = (P_total(1)*UnitNormalN(2,1))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(1))*I2(1)/tau_c;
    else
    % for non-blebbing region
        P_total(1) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(1)*cha_bleb(1);  % driving presure

        dI1dt(1) = (P_total(1)*UnitNormalN(1,1))/tau0_c - (k_b + k_a*P(1))*I1(1)/tau0_c + (dot_tan_I(1)*(k_b + k_a*P(1))*(I1(2)-I1(ptnum)))/...
        (((norm_tan(1))^2)*tau0_c*(2*(breaks(2)-breaks(ptnum))));

        dI2dt(1) = (P_total(1)*UnitNormalN(2,1))/tau0_c - (k_b + k_a*P(1))*I2(1)/tau0_c + (dot_tan_I(1)*(k_b + k_a*P(1))*(I2(2)-I2(ptnum)))/...
        (((norm_tan(1))^2)*tau0_c*(2*(breaks(2)-breaks(ptnum))));

        dPdt(1) = k_on*(rho_0-P(1)) - k_0_off*exp(b*k*delta*norm(I(:,1)))*P(1) + (dot_tan_I(1)*(k_b + k_a*P(1))*(P(2)-P(ptnum)))/...
        (((norm_tan(1))^2)*tau0_c*(2*(breaks(2)-breaks(ptnum))));

        % sqrt(I1(1)^2+I2(1)^2);
        dX1dt(1) = (P_total(1)*UnitNormalN(1,1))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(1))*I1(1)/tau0_c;

        dX2dt(1) = (P_total(1)*UnitNormalN(2,1))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(1))*I2(1)/tau0_c;
    end


    for i = 2: ptnum-1
        % norm_tan(i) = norm(UnitTangentN(:,i));
        norm_tan(i) = norm(UnitTangent_ini(:,i));

        if i >= region(1)&& i<= region(end)
        % for blebbing region
            cha_bleb(i)=1;
        
            P_total(i) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(i)*cha_bleb(i);  % driving presure

            dI1dt(i) = (P_total(i)*UnitNormalN(1,i))/tau_c - (k_b_bleb + k_a*P(i))*I1(i)/tau_c + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b_bleb + k_a*P(i))/tau_c * ((I1(i+1)-I1(i-1))/(2*(breaks(i+1)-breaks(i-1))));

            dI2dt(i) = (P_total(i)*UnitNormalN(2,i))/tau_c - (k_b_bleb + k_a*P(i))*I2(i)/tau_c + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b_bleb + k_a*P(i))/tau_c * ((I2(i+1)-I2(i-1))/(2*(breaks(i+1)-breaks(i-1))));

            dPdt(i) = k_on*(rho_0-P(i)) - k_0_off*exp(b*k*delta*norm(I(:,i)))*P(i) + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b_bleb + k_a*P(i))/tau_c * ((P(i+1)-P(i-1))/(2*(breaks(i+1)-breaks(i-1))));
            % sqrt(I1(i)^2+I2(i)^2)
            dX1dt(i) = (P_total(i)*UnitNormalN(1,i))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(i))*I1(i)/tau_c;

            dX2dt(i) = (P_total(i)*UnitNormalN(2,i))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(i))*I2(i)/tau_c;

        else
            % for non-blebbing region
            P_total(i) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(i)*cha_bleb(i);  % driving presure


            dI1dt(i) = (P_total(i)*UnitNormalN(1,i))/tau0_c - (k_b + k_a*P(i))*I1(i)/tau0_c + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b + k_a*P(i))/tau0_c * ((I1(i+1)-I1(i-1))/(2*(breaks(i+1)-breaks(i-1))));

            dI2dt(i) = (P_total(i)*UnitNormalN(2,i))/tau0_c - (k_b + k_a*P(i))*I2(i)/tau0_c + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b + k_a*P(i))/tau0_c * ((I2(i+1)-I2(i-1))/(2*(breaks(i+1)-breaks(i-1))));

            dPdt(i) = k_on*(rho_0-P(i)) - k_0_off*exp(b*k*delta*norm(I(:,i)))*P(i) + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b + k_a*P(i))/tau0_c * ((P(i+1)-P(i-1))/(2*(breaks(i+1)-breaks(i-1))));
            % sqrt(I1(i)^2+I2(i)^2)
            dX1dt(i) = (P_total(i)*UnitNormalN(1,i))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(i))*I1(i)/tau0_c;

            dX2dt(i) = (P_total(i)*UnitNormalN(2,i))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(i))*I2(i)/tau0_c;
        end

    end

    % for the last point

        % norm_tan(ptnum) = norm(UnitTangentN(:,ptnum));
        norm_tan(ptnum) = norm(UnitTangent_ini(:,ptnum));
        if ptnum >= region(1)&& ptnum<= region(end)
            % for blebbing region
            cha_bleb(ptnum)=1;
        
            P_total(ptnum) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(ptnum)*cha_bleb(ptnum);  % driving presure


            dI1dt(ptnum) = (P_total(ptnum)*UnitNormalN(1,ptnum))/tau_c - (k_b_bleb + k_a*P(ptnum))*I1(ptnum)/tau_c + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b_bleb + k_a*P(ptnum))/tau_c * ((I1(1)-I1(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));
    
            dI2dt(ptnum) = (P_total(ptnum)*UnitNormalN(2,ptnum))/tau_c - (k_b_bleb + k_a*P(ptnum))*I2(ptnum)/tau_c + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b_bleb + k_a*P(ptnum))/tau_c * ((I2(1)-I2(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));

            dPdt(ptnum) = k_on*(rho_0-P(ptnum)) - k_0_off*exp(b*k*delta*norm(I(:,ptnum)))*P(ptnum) + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b_bleb + k_a*P(ptnum))/tau_c * ((P(1)-P(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));
            % sqrt(I1(ptnum)^2+I2(ptnum)^2)
            dX1dt(ptnum) = (P_total(ptnum)*UnitNormalN(1,ptnum))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(ptnum))*I1(ptnum)/tau_c;

            dX2dt(ptnum) = (P_total(ptnum)*UnitNormalN(2,ptnum))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(ptnum))*I2(ptnum)/tau_c;

        else
            % for non-blebbing region
            P_total(ptnum) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(ptnum)*cha_bleb(ptnum);  % driving presure


            dI1dt(ptnum) = (P_total(ptnum)*UnitNormalN(1,ptnum))/tau0_c - (k_b + k_a*P(ptnum))*I1(ptnum)/tau0_c + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b + k_a*P(ptnum))/tau0_c * ((I1(1)-I1(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));
    
            dI2dt(ptnum) = (P_total(ptnum)*UnitNormalN(2,ptnum))/tau0_c - (k_b + k_a*P(ptnum))*I2(ptnum)/tau0_c + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b + k_a*P(ptnum))/tau0_c * ((I2(1)-I2(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));

            dPdt(ptnum) = k_on*(rho_0-P(ptnum)) - k_0_off*exp(b*k*delta*norm(I(:,ptnum)))*P(ptnum) + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b + k_a*P(ptnum))/tau0_c * ((P(1)-P(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));
            % sqrt(I1(ptnum)^2+I2(ptnum)^2)
            dX1dt(ptnum) = (P_total(ptnum)*UnitNormalN(1,ptnum))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(ptnum))*I1(ptnum)/tau0_c;

            dX2dt(ptnum) = (P_total(ptnum)*UnitNormalN(2,ptnum))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(ptnum))*I2(ptnum)/tau0_c;

        end
else
    % with cortex reformation

    k_b = k_m+ k0_c;                           % elastisity of boundary for general cell area
    
    tau_c = const_visco*tau0_c + (1-const_visco)*actin_frac* tau0_c;                % viscosity of blebbing area
    k_b_bleb = k_m + (1-const_elast)*actin_frac* k0_c;                            % elastisity of boundary for blebbing region (allowing cortex reformation)
    tau_y = const_visco*tau0_y + (1-const_visco)*(1-exp(-k_a_off_D*t))* tau0_y;
    

    % norm_tan(1) = norm(UnitTangentN(:,1));
    norm_tan(1) = norm(UnitTangent_ini(:,1));
    if 1 >= region(1)&& 1<= region(end)   
    % for blebbing region
        cha_bleb(1)=1;
    
        P_total(1) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(1)*cha_bleb(1);  % driving presure

    
        dI1dt(1) = (P_total(1)*UnitNormalN(1,1))/tau_c - (k_b_bleb + k_a*P(1))*I1(1)/tau_c + (dot_tan_I(1)*(k_b_bleb + k_a*P(1))*(I1(2)-I1(ptnum)))/...
        (((norm_tan(1))^2)*tau_c*(2*(breaks(2)-breaks(ptnum))));

        dI2dt(1) = (P_total(1)*UnitNormalN(2,1))/tau_c - (k_b_bleb + k_a*P(1))*I2(1)/tau_c + (dot_tan_I(1)*(k_b_bleb + k_a*P(1))*(I2(2)-I2(ptnum)))/...
        (((norm_tan(1))^2)*tau_c*(2*(breaks(2)-breaks(ptnum))));

        dPdt(1) = k_on*(rho_0-P(1)) - k_0_off*exp(b*k*delta*norm(I(:,1)))*P(1) + (dot_tan_I(1)*(k_b_bleb + k_a*P(1))*(P(2)-P(ptnum)))/...
        (((norm_tan(1))^2)*tau_c*(2*(breaks(2)-breaks(ptnum))));

        % sqrt(I1(1)^2+I2(1)^2);
        dX1dt(1) = (P_total(1)*UnitNormalN(1,1))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(1))*I1(1)/tau_c;

        dX2dt(1) = (P_total(1)*UnitNormalN(2,1))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(1))*I2(1)/tau_c;
    else
    % for non-blebbing region
        P_total(1) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(1)*cha_bleb(1);  % driving presure

        dI1dt(1) = (P_total(1)*UnitNormalN(1,1))/tau0_c - (k_b + k_a*P(1))*I1(1)/tau0_c + (dot_tan_I(1)*(k_b + k_a*P(1))*(I1(2)-I1(ptnum)))/...
        (((norm_tan(1))^2)*tau0_c*(2*(breaks(2)-breaks(ptnum))));

        dI2dt(1) = (P_total(1)*UnitNormalN(2,1))/tau0_c - (k_b + k_a*P(1))*I2(1)/tau0_c + (dot_tan_I(1)*(k_b + k_a*P(1))*(I2(2)-I2(ptnum)))/...
        (((norm_tan(1))^2)*tau0_c*(2*(breaks(2)-breaks(ptnum))));

        dPdt(1) = k_on*(rho_0-P(1)) - k_0_off*exp(b*k*delta*norm(I(:,1)))*P(1) + (dot_tan_I(1)*(k_b + k_a*P(1))*(P(2)-P(ptnum)))/...
        (((norm_tan(1))^2)*tau0_c*(2*(breaks(2)-breaks(ptnum))));

        % sqrt(I1(1)^2+I2(1)^2);
        dX1dt(1) = (P_total(1)*UnitNormalN(1,1))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(1))*I1(1)/tau0_c;

        dX2dt(1) = (P_total(1)*UnitNormalN(2,1))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(1))*I2(1)/tau0_c;
    end


    for i = 2: ptnum-1
        % norm_tan(i) = norm(UnitTangentN(:,i));
        norm_tan(i) = norm(UnitTangent_ini(:,i));

        if i >= region(1)&& i<= region(end)
        % for blebbing region
            cha_bleb(i)=1;
        
            P_total(i) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(i)*cha_bleb(i);  % driving presure

            dI1dt(i) = (P_total(i)*UnitNormalN(1,i))/tau_c - (k_b_bleb + k_a*P(i))*I1(i)/tau_c + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b_bleb + k_a*P(i))/tau_c * ((I1(i+1)-I1(i-1))/(2*(breaks(i+1)-breaks(i-1))));

            dI2dt(i) = (P_total(i)*UnitNormalN(2,i))/tau_c - (k_b_bleb + k_a*P(i))*I2(i)/tau_c + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b_bleb + k_a*P(i))/tau_c * ((I2(i+1)-I2(i-1))/(2*(breaks(i+1)-breaks(i-1))));

            dPdt(i) = k_on*(rho_0-P(i)) - k_0_off*exp(b*k*delta*norm(I(:,i)))*P(i) + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b_bleb + k_a*P(i))/tau_c * ((P(i+1)-P(i-1))/(2*(breaks(i+1)-breaks(i-1))));
            % sqrt(I1(i)^2+I2(i)^2)
            dX1dt(i) = (P_total(i)*UnitNormalN(1,i))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(i))*I1(i)/tau_c;

            dX2dt(i) = (P_total(i)*UnitNormalN(2,i))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(i))*I2(i)/tau_c;

        else
            % for non-blebbing region
            P_total(i) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(i)*cha_bleb(i);  % driving presure


            dI1dt(i) = (P_total(i)*UnitNormalN(1,i))/tau0_c - (k_b + k_a*P(i))*I1(i)/tau0_c + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b + k_a*P(i))/tau0_c * ((I1(i+1)-I1(i-1))/(2*(breaks(i+1)-breaks(i-1))));

            dI2dt(i) = (P_total(i)*UnitNormalN(2,i))/tau0_c - (k_b + k_a*P(i))*I2(i)/tau0_c + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b + k_a*P(i))/tau0_c * ((I2(i+1)-I2(i-1))/(2*(breaks(i+1)-breaks(i-1))));

            dPdt(i) = k_on*(rho_0-P(i)) - k_0_off*exp(b*k*delta*norm(I(:,i)))*P(i) + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b + k_a*P(i))/tau0_c * ((P(i+1)-P(i-1))/(2*(breaks(i+1)-breaks(i-1))));
            % sqrt(I1(i)^2+I2(i)^2)
            dX1dt(i) = (P_total(i)*UnitNormalN(1,i))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(i))*I1(i)/tau0_c;

            dX2dt(i) = (P_total(i)*UnitNormalN(2,i))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(i))*I2(i)/tau0_c;
        end

    end

    % for the last point

        % norm_tan(ptnum) = norm(UnitTangentN(:,ptnum));
        norm_tan(ptnum) = norm(UnitTangent_ini(:,ptnum));
        if ptnum >= region(1)&& ptnum<= region(end)
            % for blebbing region
            cha_bleb(ptnum)=1;
        
            P_total(ptnum) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(ptnum)*cha_bleb(ptnum);  % driving presure


            dI1dt(ptnum) = (P_total(ptnum)*UnitNormalN(1,ptnum))/tau_c - (k_b_bleb + k_a*P(ptnum))*I1(ptnum)/tau_c + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b_bleb + k_a*P(ptnum))/tau_c * ((I1(1)-I1(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));
    
            dI2dt(ptnum) = (P_total(ptnum)*UnitNormalN(2,ptnum))/tau_c - (k_b_bleb + k_a*P(ptnum))*I2(ptnum)/tau_c + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b_bleb + k_a*P(ptnum))/tau_c * ((I2(1)-I2(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));

            dPdt(ptnum) = k_on*(rho_0-P(ptnum)) - k_0_off*exp(b*k*delta*norm(I(:,ptnum)))*P(ptnum) + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b_bleb + k_a*P(ptnum))/tau_c * ((P(1)-P(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));
            % sqrt(I1(ptnum)^2+I2(ptnum)^2)
            dX1dt(ptnum) = (P_total(ptnum)*UnitNormalN(1,ptnum))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(ptnum))*I1(ptnum)/tau_c;

            dX2dt(ptnum) = (P_total(ptnum)*UnitNormalN(2,ptnum))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(ptnum))*I2(ptnum)/tau_c;

        else
            % for non-blebbing region
            P_total(ptnum) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(ptnum)*cha_bleb(ptnum);  % driving presure


            dI1dt(ptnum) = (P_total(ptnum)*UnitNormalN(1,ptnum))/tau0_c - (k_b + k_a*P(ptnum))*I1(ptnum)/tau0_c + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b + k_a*P(ptnum))/tau0_c * ((I1(1)-I1(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));
    
            dI2dt(ptnum) = (P_total(ptnum)*UnitNormalN(2,ptnum))/tau0_c - (k_b + k_a*P(ptnum))*I2(ptnum)/tau0_c + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b + k_a*P(ptnum))/tau0_c * ((I2(1)-I2(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));

            dPdt(ptnum) = k_on*(rho_0-P(ptnum)) - k_0_off*exp(b*k*delta*norm(I(:,ptnum)))*P(ptnum) + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b + k_a*P(ptnum))/tau0_c * ((P(1)-P(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));
            % sqrt(I1(ptnum)^2+I2(ptnum)^2)
            dX1dt(ptnum) = (P_total(ptnum)*UnitNormalN(1,ptnum))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(ptnum))*I1(ptnum)/tau0_c;

            dX2dt(ptnum) = (P_total(ptnum)*UnitNormalN(2,ptnum))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(ptnum))*I2(ptnum)/tau0_c;

        end
end
    % 
    % store values in sol_sys
    sol_sys(1:5:end-4) = dI1dt;
    sol_sys(2:5:end-3) = dI2dt;
    sol_sys(3:5:end-2) = dPdt;
    sol_sys(4:5:end-1) = dX1dt;
    sol_sys(5:5:end) = dX2dt;

    %sol_sys = [dI1dt;dI2dt;dPdt;dX1dt;dX2dt];
    
   

end

