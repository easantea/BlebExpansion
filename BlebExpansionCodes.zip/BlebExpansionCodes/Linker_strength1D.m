% Code to evaluate effect of linker protein strength on bleb size
% Dinuka Sewwandi and Emmanuel Asante-Asamani
% 12/27/2024

%*****************************************************************
close all; 
clear; 
clc
%*****************************************************************

t_final =25;                                % final time

%% Model parameters
parm1 = [0.005,0.01,0.05,0.1,0.2];            % Strength of single linker protein nN/(um)
parm2 = [0.1565,0.0792,0.0160,0.0080,0.0040]; % Critical strain for high pressure
parm3 = [0.1178,0.0595,0.0120,0.0060,0.0030]; % Critical strain for low pressure


%% Effect of high pressure on bleb size
figure(1)
set(0,'defaultaxesfontsize',25);
linestyles = {'-o','--s',':d','-x','-^'};
color_mat=[ 0 0 0; 0 0.4470 0.7410;0.8500 0.3250 0.0980;0.4940 0.1840 0.5560;0.6350 0.0780 0.1840];
for i = 1:5
       [t,y] = ode23s(@(t,y)sysp1(t,y),[0 t_final],parm2(i));
       plot(t,y-parm2(i),linestyles{i},'LineWidth',3,'Color',color_mat(i,:),'MarkerSize',5)
       hold on
end
xlabel('Time (secs)')
ylabel('Bleb size (\mu m)')
legend('$k_a=0.005$','$k_a=0.01$','$k_a=0.05$','$k_a=0.1$','$k_a=0.2$','Interpreter','latex')
grid on
hold off

%% Effect of low pressure on bleb size
figure(2)
set(0,'defaultaxesfontsize',25);
linestyles = {'-o','--s',':d','-x','-^'};
color_mat=[ 0 0 0; 0 0.4470 0.7410;0.8500 0.3250 0.0980;0.4940 0.1840 0.5560;0.6350 0.0780 0.1840];
for i = 1:5
       [t,y] = ode23s(@(t,y)sysp2(t,y),[0 t_final],parm3(i));
       plot(t,y-parm3(i),linestyles{i},'LineWidth',3,'Color',color_mat(i,:),'MarkerSize',5)
       hold on
end
xlabel('Time (secs)')
ylabel('Bleb size (\mu m)')
legend('$k_a=0.005$','$k_a=0.01$','$k_a=0.05$','$k_a=0.1$','$k_a=0.2$','Interpreter','latex')
grid on
hold off



%% function using to solve l and rho_a with ode45

function sol_sys = sysp1(t,y)

F0 = 0.08;                  % Cellular pressure nN/(um)^2
m = 0.1;                    % Rate at which driving pressure decreases 

k_a_on = 0.7602;            % Actin polymerization rate 
k_a_off = 0.4344;           % Actin depolymerization rate 
k_as_off = 0.0120;          % Actin disassembly rate at the actin scar

k0_c = 0.098;               % Cortex stiffness nN/(um)^3
k_m = 0.0039;               % Membrane stiffness nN/(um)^3

tau0_c = 0.064;             % Viscosity coefficient of the full cortex nNs/(um)^3
tau0_y = 6.09;               % nNs/(um)^3


gamma = 1/250;
F = (F0)* exp(-m*y(1));
k_b = k_m + k0_c*k_a_on*(1-exp(-k_a_off*t))/k_a_off;
tau_c = tau0_c*k_a_on*(1-exp(-k_a_off*t))/k_a_off;
tau_y = gamma*tau0_y + (1-gamma)*tau0_y*(1-exp(-k_as_off*t));

dldt = F/(tau_c+tau_y) - (k_b)*y(1)/(tau_c+tau_y);

sol_sys =dldt;

end


function sol_sys = sysp2(t,y)

F0 = 0.06;                  % Cellular pressure nN/(um)^2
m = 0.1;                    % Rate at which driving pressure decreases 

k_a_on = 0.7602;            % Actin polymerization rate 
k_a_off = 0.4344;           % Actin depolymerization rate 
k_as_off = 0.0120;          % Actin disassembly rate at the actin scar

k0_c = 0.098;               % Cortex stiffness nN/(um)^3
k_m = 0.0039;               % Membrane stiffness nN/(um)^3

tau0_c = 0.064;             % Viscosity coefficient of the full cortex nNs/(um)^3
tau0_y = 6.09;               % nNs/(um)^3


gamma = 1/250;
F = (F0)* exp(-m*y(1));
k_b = k_m + k0_c*k_a_on*(1-exp(-k_a_off*t))/k_a_off;
tau_c = tau0_c*k_a_on*(1-exp(-k_a_off*t))/k_a_off;
tau_y = gamma*tau0_y + (1-gamma)*tau0_y*(1-exp(-k_as_off*t));

dldt = F/(tau_c+tau_y) - (k_b)*y(1)/(tau_c+tau_y);

sol_sys =dldt;

end