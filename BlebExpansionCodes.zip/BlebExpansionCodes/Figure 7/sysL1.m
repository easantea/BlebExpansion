function sol_sys = sysL1(t,y,region,UnitTangent,cell_area,lparm)

% Solves the blebbing model with different excess pressure but the same
% resting pressure

P0_cell = 0.08;%0.06;%0.08;             % Cellular pressure nN/(um)^2
k_a = lparm;%0.1;%10^(-1);%0.001;         % Strength of single adhesion protein  nN/(um)
k_on = 10^4;                            % Binding rate of adhesion protein s^(-1)
k_0_off = 10;                           % Detaching rate of adhesion protein S^(-1)
b = 10^(6)/4.1;                         % Inverse of thermal energy.
k =k_a;                                 % Strength of linker protein
delta = 10^(-3);                        % characteristic bond length (um)
rho_0 = 10^2;                           % Total available density of adhesion protein (um)^(-2)
k0_c = 0.098;                           % Spring constant for the cortex nN/(um)^3
k_m = 0.0039;                           % membrane elasticity
tau0_c = 0.064;                         % Viscosity coefficient of the full cortex nNs/(um)^3
tau0_y =6.09;                           % Viscosity coefficient of cytoplasm nNs/(um)^3
P_start =0.05;%0.04;%0.05;              % excess presure due to contraction nN/(um)^2 % 0.05 for P0=0.08 & 0.04 for P0=0.06
% P_e = 0.02;                           % enviranment pressure nN/(um)^2
k_cell = 0.225;%225 ;%2250;             % cell bulk modulus (nN/(um)^2)
gamma_mem = 0.032;%0.032;%0.024;%40;    % membrane tension (nN/um) % 0.032 for high P & 0.024 for low P
gamma_cor = 0.1;%250;                   % cortical tension (nN/um) %s ame for both low & high pressure

% Actin dynamics
k_a_on = 0.7602;                        % polymerization rate of actin in reforming cortex
k_a_off = 0.4344;                       % depolymerization rate of actin in reforming cortex
%k_a_off_eq = 0.4344;
k_a_off_D =0.0160; %0.0120;             % disassembly rate of actin in degrading cortex
actin_rest = k_a_on/k_a_off;            % resting actin concentration in the expanding bleb
%actin_0_rest = k_a_on/k_a_off_eq;       % Resting actin concentration in the expanding bleb
actin_con = actin_rest * (1-exp(-k_a_off*t)); % actin concentration in reforming cortex
gamma = 1/250;
%actin_frac = actin_con/actin_0_rest;

% const_elast = 1/25;                   % potion of cotical elasticity
 %const_visco = 1/25;                   % potion of viscosity of cotex

time_lap = 2;                           % wait time for cortex reformation to begin.



area_rest = cell_area;                    % constant value %78.7865 is the resting area for cell when P0 =0.08 & k_a =0.1
 
% separating I1,I2,P,xdata,ydata values from the y0
I1 = y(1:5:end-4);
I2 = y(2:5:end-3);
P = y(3:5:end-2);
P(region) = zeros(length(region),1);    % set adhesion proteins to zero in the blebbing region.
xdata = y(4:5:end-1);
ydata = y(5:5:end);
xdata(end+1) = xdata(1);                % repeats the first point at the last point
ydata(end+1)= ydata(1);


% Construct parametric cubic spline
csevalN = [xdata'; ydata'];

% Calculate curvature and unit normals
[csplineN,CurvatureN,UnitNormalN,UnitTangentN]= splinecurvature(csevalN);
breaks = csplineN.breaks;               % parametrization
%breaks0= breaks
UnitTangent_ini = UnitTangent;
ptnum = length(breaks)-1;               % number of distinct points
P_bleb =  2*(gamma_mem+gamma_cor)*CurvatureN(1:ptnum);

 % calculating new area
area_new = cal_areafun(csplineN,ptnum);


%P_total = P0_cell + P_start;
cha_bleb = zeros(1,ptnum);
P_total = zeros(1,ptnum);
dI1dt = zeros(1,ptnum);
dI2dt = zeros(1,ptnum);
dPdt  = zeros(1,ptnum);
dX1dt = zeros(1,ptnum);
dX2dt = zeros(1,ptnum);
norm_tan = zeros(1,ptnum);

sol_sys = zeros(5*ptnum,1);
% dot_tan_V = dot(UnitTangent(:,1:ptnum),v);


I = [I1';I2']; 
% A =UnitTangentN(:,1:ptnum);               % use new tangent
A =UnitTangent_ini(:,1:ptnum);              % use old tangent
dot_tan_I = dot(A,I,1);

% bleb without cortex
if t < time_lap
    k_b = k_m+ k0_c;                        % elastisity of boundary for general cell area
    tau_c = 0;                              % viscosity of blebbing area
    tau_y = gamma*tau0_y;                   % viscosity of blebbing area
     
    k_b_bleb = k_m;                         % elastisity of boundary for blebbing region (allowing cortex reformation)

    % for the 1st point
    % norm_tan(1) = norm(UnitTangentN(:,1));
    norm_tan(1) = norm(UnitTangent_ini(:,1));
    
    if 1 >= region(1)&& 1<= region(end)   
    % for blebbing region
        cha_bleb(1)=1;
    
        P_total(1) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(1)*cha_bleb(1);  % driving presure

    
        dI1dt(1) = (P_total(1)*UnitNormalN(1,1))/(tau_c+tau_y) - (k_b_bleb + k_a*P(1))*I1(1)/(tau_c+tau_y) + (dot_tan_I(1)*(k_b_bleb + k_a*P(1))*(I1(2)-I1(ptnum)))/...
        (((norm_tan(1))^2)*(tau_c+tau_y)*(2*(breaks(2)-breaks(ptnum))));

        dI2dt(1) = (P_total(1)*UnitNormalN(2,1))/(tau_c+tau_y) - (k_b_bleb + k_a*P(1))*I2(1)/(tau_c+tau_y) + (dot_tan_I(1)*(k_b_bleb + k_a*P(1))*(I2(2)-I2(ptnum)))/...
        (((norm_tan(1))^2)*(tau_c+tau_y)*(2*(breaks(2)-breaks(ptnum))));

        dPdt(1) = k_on*(rho_0-P(1)) - k_0_off*exp(b*k*delta*norm(I(:,1)))*P(1) + (dot_tan_I(1)*(k_b_bleb + k_a*P(1))*(P(2)-P(ptnum)))/...
        (((norm_tan(1))^2)*(tau_c+tau_y)*(2*(breaks(2)-breaks(ptnum))));

        % sqrt(I1(1)^2+I2(1)^2);
%         dX1dt(1) = (P_total(1)*UnitNormalN(1,1))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(1))*I1(1)/tau_c;
% 
%         dX2dt(1) = (P_total(1)*UnitNormalN(2,1))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(1))*I2(1)/tau_c;

        dX1dt(1) = dIldt(1);      
        dX2dt(1) = dI2dt(1);

    else
    % for non-blebbing region

        P_total(1) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(1)*cha_bleb(1);  % driving presure

        dI1dt(1) = (P_total(1)*UnitNormalN(1,1))/(tau0_c+tau0_y) - (k_b + k_a*P(1))*I1(1)/(tau0_c+tau0_y) + (dot_tan_I(1)*(k_b + k_a*P(1))*(I1(2)-I1(ptnum)))/...
        (((norm_tan(1))^2)*(tau0_c+tau0_y)*(2*(breaks(2)-breaks(ptnum))));

        dI2dt(1) = (P_total(1)*UnitNormalN(2,1))/(tau0_c+tau0_y) - (k_b + k_a*P(1))*I2(1)/(tau0_c+tau0_y) + (dot_tan_I(1)*(k_b + k_a*P(1))*(I2(2)-I2(ptnum)))/...
        (((norm_tan(1))^2)*(tau0_c+tau0_y)*(2*(breaks(2)-breaks(ptnum))));

        dPdt(1) = k_on*(rho_0-P(1)) - k_0_off*exp(b*k*delta*norm(I(:,1)))*P(1) + (dot_tan_I(1)*(k_b + k_a*P(1))*(P(2)-P(ptnum)))/...
        (((norm_tan(1))^2)*(tau0_c+tau0_y)*(2*(breaks(2)-breaks(ptnum))));

%         % sqrt(I1(1)^2+I2(1)^2);
%         dX1dt(1) = (P_total(1)*UnitNormalN(1,1))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(1))*I1(1)/tau0_c;
% 
%         dX2dt(1) = (P_total(1)*UnitNormalN(2,1))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(1))*I2(1)/tau0_c;

        dX1dt(1) = dI1dt(1);

        dX2dt(1) = dI2dt(1);
    end


    for i = 2: ptnum-1
        % norm_tan(i) = norm(UnitTangentN(:,i));
        norm_tan(i) = norm(UnitTangent_ini(:,i));

        if i >= region(1)&& i<= region(end)
        % for blebbing region
            cha_bleb(i)=1;
        
            P_total(i) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(i)*cha_bleb(i);  % driving presure

            dI1dt(i) = (P_total(i)*UnitNormalN(1,i))/(tau_c+tau_y) - (k_b_bleb + k_a*P(i))*I1(i)/(tau_c+tau_y) + (dot_tan_I(i)/((norm_tan(i))^2))*...
            ((k_b_bleb + k_a*P(i))/(tau_c+tau_y)) * ((I1(i+1)-I1(i-1))/(2*(breaks(i+1)-breaks(i-1))));

            dI2dt(i) = (P_total(i)*UnitNormalN(2,i))/(tau_c+tau_y) - (k_b_bleb + k_a*P(i))*I2(i)/(tau_c+tau_y) + dot_tan_I(i)/((norm_tan(i))^2)*...
            ((k_b_bleb + k_a*P(i))/(tau_c+tau_y)) * ((I2(i+1)-I2(i-1))/(2*(breaks(i+1)-breaks(i-1))));

            dPdt(i) = k_on*(rho_0-P(i)) - k_0_off*exp(b*k*delta*norm(I(:,i)))*P(i) + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b_bleb + k_a*P(i))/(tau_c+tau_y) * ((P(i+1)-P(i-1))/(2*(breaks(i+1)-breaks(i-1))));
            % sqrt(I1(i)^2+I2(i)^2)
            
%             dX1dt(i) = (P_total(i)*UnitNormalN(1,i))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(i))*I1(i)/tau_c;
% 
%             dX2dt(i) = (P_total(i)*UnitNormalN(2,i))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(i))*I2(i)/tau_c;

            dX1dt(i) =  dI1dt(i);

            dX2dt(i) = dI2dt(i);

        else
            % for non-blebbing region
            P_total(i) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(i)*cha_bleb(i);  % driving presure


            dI1dt(i) = (P_total(i)*UnitNormalN(1,i))/(tau0_c+tau0_y) - (k_b + k_a*P(i))*I1(i)/(tau0_c+tau0_y) + dot_tan_I(i)/((norm_tan(i))^2)*...
            ((k_b + k_a*P(i))/(tau0_c+tau0_y)) * ((I1(i+1)-I1(i-1))/(2*(breaks(i+1)-breaks(i-1))));

            dI2dt(i) = (P_total(i)*UnitNormalN(2,i))/(tau0_c+tau0_y) - (k_b + k_a*P(i))*I2(i)/(tau0_c+tau0_y) + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b + k_a*P(i))/(tau0_c+tau0_y) * ((I2(i+1)-I2(i-1))/(2*(breaks(i+1)-breaks(i-1))));

            dPdt(i) = k_on*(rho_0-P(i)) - k_0_off*exp(b*k*delta*norm(I(:,i)))*P(i) + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b + k_a*P(i))/(tau0_c+tau0_y) * ((P(i+1)-P(i-1))/(2*(breaks(i+1)-breaks(i-1))));
            % sqrt(I1(i)^2+I2(i)^2)
%             
%             dX1dt(i) = (P_total(i)*UnitNormalN(1,i))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(i))*I1(i)/tau0_c;
% 
%             dX2dt(i) = (P_total(i)*UnitNormalN(2,i))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(i))*I2(i)/tau0_c;

            
            dX1dt(i) = dI1dt(i);

            dX2dt(i) = dI2dt(i);
        end

    end

    % for the last point

        % norm_tan(ptnum) = norm(UnitTangentN(:,ptnum));
        norm_tan(ptnum) = norm(UnitTangent_ini(:,ptnum));
        if ptnum >= region(1)&& ptnum<= region(end)
            % for blebbing region
            cha_bleb(ptnum)=1;
        
            P_total(ptnum) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(ptnum)*cha_bleb(ptnum);  % driving presure


            dI1dt(ptnum) = (P_total(ptnum)*UnitNormalN(1,ptnum))/(tau_c+tau_y) - (k_b_bleb + k_a*P(ptnum))*I1(ptnum)/(tau_c+tau_y) + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b_bleb + k_a*P(ptnum))/(tau_c+tau_y) * ((I1(1)-I1(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));
    
            dI2dt(ptnum) = (P_total(ptnum)*UnitNormalN(2,ptnum))/(tau_c+tau_y) - (k_b_bleb + k_a*P(ptnum))*I2(ptnum)/(tau_c +tau_y)+ dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b_bleb + k_a*P(ptnum))/(tau_c+tau_y) * ((I2(1)-I2(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));

            dPdt(ptnum) = k_on*(rho_0-P(ptnum)) - k_0_off*exp(b*k*delta*norm(I(:,ptnum)))*P(ptnum) + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b_bleb + k_a*P(ptnum))/(tau_c+tau_y) * ((P(1)-P(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));
            % sqrt(I1(ptnum)^2+I2(ptnum)^2)
            
%             dX1dt(ptnum) = (P_total(ptnum)*UnitNormalN(1,ptnum))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(ptnum))*I1(ptnum)/tau_c;
% 
%             dX2dt(ptnum) = (P_total(ptnum)*UnitNormalN(2,ptnum))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(ptnum))*I2(ptnum)/tau_c;

            dX1dt(ptnum) = dI1dt(ptnum);

            dX2dt(ptnum) = dI2dt(ptnum);

        else
            % for non-blebbing region
            P_total(ptnum) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(ptnum)*cha_bleb(ptnum);  % driving presure


            dI1dt(ptnum) = (P_total(ptnum)*UnitNormalN(1,ptnum))/(tau0_c+tau0_y) - (k_b + k_a*P(ptnum))*I1(ptnum)/(tau0_c+tau0_y) + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b + k_a*P(ptnum))/(tau0_c+tau0_y) * ((I1(1)-I1(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));
    
            dI2dt(ptnum) = (P_total(ptnum)*UnitNormalN(2,ptnum))/(tau0_c+tau0_y) - (k_b + k_a*P(ptnum))*I2(ptnum)/(tau0_c+tau0_y) + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b + k_a*P(ptnum))/(tau0_c+tau0_y) * ((I2(1)-I2(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));

            dPdt(ptnum) = k_on*(rho_0-P(ptnum)) - k_0_off*exp(b*k*delta*norm(I(:,ptnum)))*P(ptnum) + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b + k_a*P(ptnum))/(tau0_c+tau0_y) * ((P(1)-P(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));
            % sqrt(I1(ptnum)^2+I2(ptnum)^2) 
            
%             dX1dt(ptnum) = (P_total(ptnum)*UnitNormalN(1,ptnum))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(ptnum))*I1(ptnum)/tau0_c;
% 
%             dX2dt(ptnum) = (P_total(ptnum)*UnitNormalN(2,ptnum))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(ptnum))*I2(ptnum)/tau0_c;

            dX1dt(ptnum) = dI1dt(ptnum) ;

            dX2dt(ptnum) = dI2dt(ptnum) ;

        end
else
    % with cortex reformation

    k_b = k_m+ k0_c;                           % elastisity of boundary for general cell area
    
%     tau_c = const_visco*tau0_c + (1-const_visco)*actin_frac* tau0_c;                % viscosity of blebbing area
%     k_b_bleb = k_m + (1-const_elast)*actin_frac* k0_c;                            % elastisity of boundary for blebbing region (allowing cortex reformation)
%     tau_y = const_visco*tau0_y + (1-const_visco)*(1-exp(-k_a_off_D*t))* tau0_y;
%     
  
    tau_c = actin_con*tau0_c;                                                     % viscosity of blebbing area
    k_b_bleb = k_m + actin_con* k0_c;                                            % elastisity of boundary for blebbing region (allowing cortex reformation)
    tau_y = gamma*tau0_y + (1-gamma)*(1-exp(-k_a_off_D*t))* tau0_y;

    % norm_tan(1) = norm(UnitTangentN(:,1));
    norm_tan(1) = norm(UnitTangent_ini(:,1));
    if 1 >= region(1)&& 1<= region(end)   
    % for blebbing region
        cha_bleb(1)=1;
    
        P_total(1) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(1)*cha_bleb(1);  % driving presure

    
        dI1dt(1) = (P_total(1)*UnitNormalN(1,1))/(tau_c+tau_y) - (k_b_bleb + k_a*P(1))*I1(1)/(tau_c+tau_y) + (dot_tan_I(1)*(k_b_bleb + k_a*P(1))*(I1(2)-I1(ptnum)))/...
        (((norm_tan(1))^2)*(tau_c+tau_y)*(2*(breaks(2)-breaks(ptnum))));

        dI2dt(1) = (P_total(1)*UnitNormalN(2,1))/(tau_c+tau_y) - (k_b_bleb + k_a*P(1))*I2(1)/(tau_c+tau_y) + (dot_tan_I(1)*(k_b_bleb + k_a*P(1))*(I2(2)-I2(ptnum)))/...
        (((norm_tan(1))^2)*(tau_c+tau_y)*(2*(breaks(2)-breaks(ptnum))));

        dPdt(1) = k_on*(rho_0-P(1)) - k_0_off*exp(b*k*delta*norm(I(:,1)))*P(1) + (dot_tan_I(1)*(k_b_bleb + k_a*P(1))*(P(2)-P(ptnum)))/...
        (((norm_tan(1))^2)*(tau_c+tau_y)*(2*(breaks(2)-breaks(ptnum))));

        % sqrt(I1(1)^2+I2(1)^2);
%         dX1dt(1) = (P_total(1)*UnitNormalN(1,1))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(1))*I1(1)/tau_c;
% 
%         dX2dt(1) = (P_total(1)*UnitNormalN(2,1))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(1))*I2(1)/tau_c;
           dX1dt(1) = dI1dt(1) ;

            dX2dt(1) = dI2dt(1) ;
    else
    % for non-blebbing region
        P_total(1) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(1)*cha_bleb(1);  % driving presure

        dI1dt(1) = (P_total(1)*UnitNormalN(1,1))/(tau0_c+tau0_y) - (k_b + k_a*P(1))*I1(1)/(tau0_c+tau0_y) + (dot_tan_I(1)*(k_b + k_a*P(1))*(I1(2)-I1(ptnum)))/...
        (((norm_tan(1))^2)*(tau0_c+tau0_y)*(2*(breaks(2)-breaks(ptnum))));

        dI2dt(1) = (P_total(1)*UnitNormalN(2,1))/(tau0_c+tau0_y) - (k_b + k_a*P(1))*I2(1)/(tau0_c+tau0_y) + (dot_tan_I(1)*(k_b + k_a*P(1))*(I2(2)-I2(ptnum)))/...
        (((norm_tan(1))^2)*(tau0_c+tau0_y)*(2*(breaks(2)-breaks(ptnum))));

        dPdt(1) = k_on*(rho_0-P(1)) - k_0_off*exp(b*k*delta*norm(I(:,1)))*P(1) + (dot_tan_I(1)*(k_b + k_a*P(1))*(P(2)-P(ptnum)))/...
        (((norm_tan(1))^2)*(tau0_c+tau0_y)*(2*(breaks(2)-breaks(ptnum))));

        % sqrt(I1(1)^2+I2(1)^2);
%         dX1dt(1) = (P_total(1)*UnitNormalN(1,1))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(1))*I1(1)/tau0_c;
% 
%         dX2dt(1) = (P_total(1)*UnitNormalN(2,1))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(1))*I2(1)/tau0_c;

            dX1dt(1) = dI1dt(1) ;

            dX2dt(1) = dI2dt(1) ;
    end


    for i = 2: ptnum-1
        % norm_tan(i) = norm(UnitTangentN(:,i));
        norm_tan(i) = norm(UnitTangent_ini(:,i));

        if i >= region(1)&& i<= region(end)
        % for blebbing region
            cha_bleb(i)=1;
        
            P_total(i) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(i)*cha_bleb(i);  % driving presure

            dI1dt(i) = (P_total(i)*UnitNormalN(1,i))/(tau_c+tau_y) - (k_b_bleb + k_a*P(i))*I1(i)/(tau_c+tau_y) + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b_bleb + k_a*P(i))/(tau_c+tau_y) * ((I1(i+1)-I1(i-1))/(2*(breaks(i+1)-breaks(i-1))));

            dI2dt(i) = (P_total(i)*UnitNormalN(2,i))/(tau_c+tau_y) - (k_b_bleb + k_a*P(i))*I2(i)/(tau_c+tau_y) + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b_bleb + k_a*P(i))/(tau_c+tau_y) * ((I2(i+1)-I2(i-1))/(2*(breaks(i+1)-breaks(i-1))));

            dPdt(i) = k_on*(rho_0-P(i)) - k_0_off*exp(b*k*delta*norm(I(:,i)))*P(i) + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b_bleb + k_a*P(i))/(tau_c+tau_y) * ((P(i+1)-P(i-1))/(2*(breaks(i+1)-breaks(i-1))));
            % sqrt(I1(i)^2+I2(i)^2)
%             
%             dX1dt(i) = (P_total(i)*UnitNormalN(1,i))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(i))*I1(i)/tau_c;
% 
%             dX2dt(i) = (P_total(i)*UnitNormalN(2,i))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(i))*I2(i)/tau_c;

              
            dX1dt(i) = dI1dt(i);

            dX2dt(i) = dI2dt(i);
        else
            % for non-blebbing region
            P_total(i) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(i)*cha_bleb(i);  % driving presure


            dI1dt(i) = (P_total(i)*UnitNormalN(1,i))/(tau0_c+tau0_y) - (k_b + k_a*P(i))*I1(i)/(tau0_c+tau0_y) + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b + k_a*P(i))/(tau0_c+tau0_y) * ((I1(i+1)-I1(i-1))/(2*(breaks(i+1)-breaks(i-1))));

            dI2dt(i) = (P_total(i)*UnitNormalN(2,i))/(tau0_c+tau0_y) - (k_b + k_a*P(i))*I2(i)/(tau0_c+tau0_y) + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b + k_a*P(i))/(tau0_c+tau0_y)* ((I2(i+1)-I2(i-1))/(2*(breaks(i+1)-breaks(i-1))));

            dPdt(i) = k_on*(rho_0-P(i)) - k_0_off*exp(b*k*delta*norm(I(:,i)))*P(i) + dot_tan_I(i)/((norm_tan(i))^2)*...
            (k_b + k_a*P(i))/(tau0_c+tau0_y) * ((P(i+1)-P(i-1))/(2*(breaks(i+1)-breaks(i-1))));
            % sqrt(I1(i)^2+I2(i)^2)
%             
%             dX1dt(i) = (P_total(i)*UnitNormalN(1,i))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(i))*I1(i)/tau0_c;
% 
%             dX2dt(i) = (P_total(i)*UnitNormalN(2,i))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(i))*I2(i)/tau0_c;

            dX1dt(i) = dI1dt(i);

            dX2dt(i) = dI2dt(i);
        end

    end

    % for the last point

        % norm_tan(ptnum) = norm(UnitTangentN(:,ptnum));
        norm_tan(ptnum) = norm(UnitTangent_ini(:,ptnum));
        if ptnum >= region(1)&& ptnum<= region(end)
            % for blebbing region
            cha_bleb(ptnum)=1;
        
            P_total(ptnum) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(ptnum)*cha_bleb(ptnum);  % driving presure


            dI1dt(ptnum) = (P_total(ptnum)*UnitNormalN(1,ptnum))/(tau_c+tau_y) - (k_b_bleb + k_a*P(ptnum))*I1(ptnum)/(tau_c+tau_y) + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b_bleb + k_a*P(ptnum))/(tau_c+tau_y) * ((I1(1)-I1(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));
    
            dI2dt(ptnum) = (P_total(ptnum)*UnitNormalN(2,ptnum))/(tau_c+tau_y) - (k_b_bleb + k_a*P(ptnum))*I2(ptnum)/(tau_c+tau_y) + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b_bleb + k_a*P(ptnum))/(tau_c+tau_y) * ((I2(1)-I2(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));

            dPdt(ptnum) = k_on*(rho_0-P(ptnum)) - k_0_off*exp(b*k*delta*norm(I(:,ptnum)))*P(ptnum) + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b_bleb + k_a*P(ptnum))/(tau_c+tau_y) * ((P(1)-P(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));
            % sqrt(I1(ptnum)^2+I2(ptnum)^2)
            
%             dX1dt(ptnum) = (P_total(ptnum)*UnitNormalN(1,ptnum))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(ptnum))*I1(ptnum)/tau_c;
% 
%             dX2dt(ptnum) = (P_total(ptnum)*UnitNormalN(2,ptnum))*((1/tau_c)+(1/tau_y)) - (k_b_bleb + k_a*P(ptnum))*I2(ptnum)/tau_c;
            dX1dt(ptnum) = dI1dt(ptnum);

            dX2dt(ptnum) = dI2dt(ptnum);

        else
            % for non-blebbing region
            P_total(ptnum) = P0_cell + P_start + k_cell* log(area_rest/area_new)-P_bleb(ptnum)*cha_bleb(ptnum);  % driving presure


            dI1dt(ptnum) = (P_total(ptnum)*UnitNormalN(1,ptnum))/(tau0_c+tau0_y) - (k_b + k_a*P(ptnum))*I1(ptnum)/(tau0_c+tau0_y) + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b + k_a*P(ptnum))/(tau0_c+tau0_y) * ((I1(1)-I1(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));
    
            dI2dt(ptnum) = (P_total(ptnum)*UnitNormalN(2,ptnum))/(tau0_c+tau0_y) - (k_b + k_a*P(ptnum))*I2(ptnum)/(tau0_c+tau0_y) + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b + k_a*P(ptnum))/(tau0_c+tau0_y) * ((I2(1)-I2(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));

            dPdt(ptnum) = k_on*(rho_0-P(ptnum)) - k_0_off*exp(b*k*delta*norm(I(:,ptnum)))*P(ptnum) + dot_tan_I(ptnum)/((norm_tan(ptnum))^2)*...
            (k_b + k_a*P(ptnum))/(tau0_c+tau0_y) * ((P(1)-P(ptnum-1))/(2*(breaks(1)-breaks(ptnum-1))));
            % sqrt(I1(ptnum)^2+I2(ptnum)^2)
            
            
%             dX1dt(ptnum) = (P_total(ptnum)*UnitNormalN(1,ptnum))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(ptnum))*I1(ptnum)/tau0_c;
% 
%             dX2dt(ptnum) = (P_total(ptnum)*UnitNormalN(2,ptnum))*((1/tau0_c)+(1/tau0_y)) - (k_b + k_a*P(ptnum))*I2(ptnum)/tau0_c;

            dX1dt(ptnum) = dI1dt(ptnum);

            dX2dt(ptnum) = dI2dt(ptnum);

        end
end
    % 
    % store values in sol_sys
    sol_sys(1:5:end-4) = dI1dt;
    sol_sys(2:5:end-3) = dI2dt;
    sol_sys(3:5:end-2) = dPdt;
    sol_sys(4:5:end-1) = dX1dt;
    sol_sys(5:5:end) = dX2dt;

    %sol_sys = [dI1dt;dI2dt;dPdt;dX1dt;dX2dt];
    
   

end