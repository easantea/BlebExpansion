To generate Figure 7 run BlebExpansion2D_LinkerStrength_Fig7.m
